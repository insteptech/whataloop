const unsupportedDBType = "Unsupported DB Type";
const unableConnect = "Unable to connect to the database";

module.exports = {
  unsupportedDBType,
  unableConnect,
};
