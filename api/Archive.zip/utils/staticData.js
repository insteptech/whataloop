const supportedDbTypes = {
  postgres: "postgres",
  mysql: "mysql",
  mssql: "mssql",
};

module.exports = {
  supportedDbTypes,
};
