const mainData = require("../../../utils/staticData");

module.exports = {
  ...mainData,
};
