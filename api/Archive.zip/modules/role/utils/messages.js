const mainMessages = require("../../../utils/messages");

module.exports = {
  ...mainMessages,
};
