exports.roleInput = [
  { key: "name", type: "string", required: true },
  { key: "description", type: "string", required: false },
];
