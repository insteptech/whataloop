exports.routeParams = [
  {
    route: "role/create",
    params: { name: "" },
    authRequired: true,
    method: "post",
    tag: "role",
  },
];
