const roleRoute = require("./role");

const routes = [
  {
    path: "/role",
    route: roleRoute,
  },
];

module.exports = routes;
