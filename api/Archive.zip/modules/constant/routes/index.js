// Content for index.js
const constantRoute = require("./constant");

const routes = [
  {
    path: "/constant",
    route: constantRoute,
  },
];

module.exports = routes;
