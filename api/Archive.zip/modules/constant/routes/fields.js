// Content for fields.js
exports.routeParams = []