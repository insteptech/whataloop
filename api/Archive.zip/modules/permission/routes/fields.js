exports.routeParams = [
  {
    route: "permission/create",
    params: { name: "" },
    authRequired: true,
    method: "post",
    tag: "permission",
  },
];
