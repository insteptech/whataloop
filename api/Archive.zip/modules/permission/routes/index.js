const permissionRoute = require("./permission");

const routes = [
  {
    path: "/permission",
    route: permissionRoute,
  },
];

module.exports = routes;
