exports.permissionInput = [
  { key: "name", type: "string", required: true },
  { key: "description", type: "string", required: false },
  { key: "route", type: "string", required: false },
  { key: "action", type: "string", required: true },
  { key: "type", type: "string", required: false },
];
