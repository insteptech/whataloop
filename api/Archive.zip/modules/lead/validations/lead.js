exports.otpInput = [{ key: "email", type: "string", required: true }];
exports.addLeadInput = [
    { key: "phone", type: "string", required: true },
    { key: "email", type: "string", required: true },
    { key: "fullName", type: "string", required: true },
    { key: "tag", type: "string", required: true },
    { key: "status", type: "string", required: true },
    { key: "source", type: "string", required: true },
    { key: "notes", type: "string", required: true },
    { key: "last_contacted", type: "string", required: true },
];