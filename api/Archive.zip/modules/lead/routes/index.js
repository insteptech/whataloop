const leadRoute = require("./lead");

const routes = [
  {
    path: "/lead",
    route: leadRoute,
  },
];

module.exports = routes;
