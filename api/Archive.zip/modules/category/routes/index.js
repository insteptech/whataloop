// Content for index.js
const categoryRoute = require("./category");

const routes = [
  {
    path: "/category",
    route: categoryRoute,
  },
];

module.exports = routes;
